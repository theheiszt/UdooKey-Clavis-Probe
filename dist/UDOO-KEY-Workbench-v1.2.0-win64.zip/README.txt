========================================================================
 UDOO KEY WORKBENCH v1.2.0 - PORTABLE STANDALONE EDITION
 Universal Dual-MCU Acquisition, Instrumentation & Diagnostics Suite
========================================================================

ABOUT:
  UDOO KEY Workbench is a professional, high-performance native desktop
  instrumentation suite for the SECO UDOO KEY (RP2040 + ESP32-WROVER-E).

FEATURES:
  * 8-Channel 100 MSPS Logic Analyzer with SUMP / PulseView support
  * Level-of-Detail (LOD) min/max hardware waveform rendering (60 FPS)
  * Protocol Decoders: UART, I2C, SPI with packet table & annotations
  * Interactive Bus Tools Workspace:
    - Mode Multiplexer with Safe Hi-Z Invariant
    - 7-bit I2C Bus Explorer & Matrix Scanner
    - SPI Master & JEDEC SFDP Flash Probe
    - Dallas 1-Wire Search ROM Tree
    - Secondary UART Bridge Monitor
    - 8-bit DIO Probe Bus with mask operations
    - Interactive Syntax Shell (square-bracket commands & macros)
    - Wireless Subsystem: Infrared (IR NEC/raw) & nRF24L01 2.4 GHz RF
  * ARM SWD DP-IDCODE Reader & IEEE 1149.1 JTAG Boundary Scan
  * Multichannel Voltmeter & Acoustic Continuity Tester
  * Apple Diagnostics & Monotonic Timestamp Correlation
  * USB Testing, Descriptor Parsing & Injection
  * Global Event Timeline & .udoo Session Container Persistence

HOW TO RUN:
  1. Simply double-click 'udoo-key-app.exe' in this directory.
     No installation or external runtime required (all Qt DLLs included).
  2. Connect your UDOO KEY via USB-C.
  3. Press Ctrl+O or click 'Connect' on the toolbar.

DIRECTORIES:
  * firmware/ : Latest verified firmware binaries for RP2040 and ESP32.
  * sessions/ : Default sample .udoo session containers (I2C, SPI, UART).
  * docs/     : Offline interactive hardware guides and pinout references.

========================================================================
